<?php

/* @author    2codeThemes
*  @package   WPQA/framework
*  @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/* Save default options */
if (!get_option(wpqa_options) || !get_option(wpqa_styling_options) || !get_option(wpqa_mobile_options)) {
	$wpqa_admin_options = new wpqa_admin_options;
	if (!get_option(wpqa_options)) {
		$default_options = $wpqa_admin_options->get_default_values("options");
		add_option(wpqa_options,$default_options);
	}
	if (!get_option(wpqa_styling_options)) {
		$default_options = $wpqa_admin_options->get_default_values("styling");
		add_option(wpqa_styling_options,$default_options);
	}
	if (!get_option(wpqa_mobile_options)) {
		$default_options = $wpqa_admin_options->get_default_values("mobile");
		add_option(wpqa_mobile_options,$default_options);
	}
}?>